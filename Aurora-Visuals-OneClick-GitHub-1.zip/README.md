# Aurora Visuals — Minecraft 1.21.4

Fabric client-side visual mod. Weather controls and weather effects have been removed.

## Build

This repository includes a GitHub Actions workflow. Upload the project files to the repository root; every push to `main` or `master` runs the build. You can also start it manually from **Actions → Build Aurora Visuals → Run workflow**.

The compiled JAR is uploaded as a workflow artifact named `Aurora-Visuals-JAR`.

Requirements: Java 21 and Gradle 8.12.
