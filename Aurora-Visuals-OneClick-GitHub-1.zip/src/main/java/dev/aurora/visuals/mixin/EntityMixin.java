package dev.aurora.visuals.mixin;

import dev.aurora.visuals.Features;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** See Invisible: невидимые сущности рисуются полупрозрачными, как для союзников по команде. */
    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void aurora$seeInvisible(PlayerEntity player, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (Features.SEE_INVISIBLE.enabled && self.getWorld().isClient) {
            cir.setReturnValue(false);
        }
    }
}
